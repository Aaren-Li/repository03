package com.shuzu.HumanManade;

public class Worker {
    public String name;
    public int age;
    public String sex;
    public int id;
    public double salary;

    public Worker(String name, int age, String sex, int id, double salary) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.id = id;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
